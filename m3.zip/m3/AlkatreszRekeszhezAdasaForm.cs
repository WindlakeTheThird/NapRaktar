﻿using System.Windows.Forms;

namespace Menu
{
    public partial class AlkatreszRekeszhezAdasaForm : Form
    {
        public AlkatreszRekeszhezAdasaForm()
        {
            InitializeComponent();
        }
    }
}
