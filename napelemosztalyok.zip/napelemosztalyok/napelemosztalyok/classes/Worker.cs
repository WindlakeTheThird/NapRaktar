﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace napelemosztalyok.classes
{
    public class Worker
    {
        public int id { get; set; }
        public string nev { get; set; }

        public Worker()
        {
               
        }
    }
}
