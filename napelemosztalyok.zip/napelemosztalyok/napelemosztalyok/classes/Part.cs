﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace napelemosztalyok.classes
{
    public class Part
    {
        public int id { get; set; }
        public string type { get; set; }
        public int amount { get; set; }
        public double unit_cost { get; set; }
    }
}
