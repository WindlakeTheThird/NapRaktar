﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace napelemosztalyok.classes
{
    public class Raktarvezeto : Worker
    {
        public Raktarvezeto()
        {

        }

        public void addPart(string i,string t,string a,string uc)
        {
            string Query = "insert into napelem.alkatresz (tipus_id,tipus,darab_rekesz,ar) values (" + i + ",\'" + t + "\'," + a + "," + uc + ")";
            string MyConnection2 = "datasource=localhost;username=root;password=";
            MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);
            //This is command class which will handle the query and connection object.  
            MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
            MySqlDataReader MyReader2;
            MyConn2.Open();
            MyReader2 = MyCommand2.ExecuteReader();     // Here our query will be executed and data saved into the database.  
            MessageBox.Show("Database exists");
            while (MyReader2.Read())
            {
            }
            MyConn2.Close();   
        }
        public void editPart(Part p,int i,string v)
        {
            switch (i)
            {
                case 0:
                    {
                        p.type = v;
                        break;
                    }
                case 1:
                    {
                        p.amount = Convert.ToInt32(v);
                        break;
                    }
                case 2:
                    {
                        p.unit_cost = Convert.ToDouble(v);
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
        }
    }
}
