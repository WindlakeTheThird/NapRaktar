﻿
namespace Menu
{
    partial class ArkalkulacioesLezaras
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.projectCalcEndUC1 = new Menu.ProjectCalcEndUC();
            this.SuspendLayout();
            // 
            // projectCalcEndUC1
            // 
            this.projectCalcEndUC1.Location = new System.Drawing.Point(12, 12);
            this.projectCalcEndUC1.Name = "projectCalcEndUC1";
            this.projectCalcEndUC1.Size = new System.Drawing.Size(800, 350);
            this.projectCalcEndUC1.TabIndex = 0;
            // 
            // ArkalkulacioesLezaras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 450);
            this.Controls.Add(this.projectCalcEndUC1);
            this.Name = "ArkalkulacioesLezaras";
            this.Text = "ArkalkulacioesLezaras";
            this.ResumeLayout(false);

        }

        #endregion

        private ProjectCalcEndUC projectCalcEndUC1;
    }
}